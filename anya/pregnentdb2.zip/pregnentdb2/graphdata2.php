<?php

if ($_SERVER["REQUEST_METHOD"] == "POST") {
    // Decode the JSON data
    $json = file_get_contents('php://input');
    $data = json_decode($json, true);

    if (isset($_POST["username"])) {
        $username = $_POST["username"];

        // Establish the database connection
        require("conn.php");

        // Check connection
        if ($conn->connect_error) {
            die("Connection failed: " . $conn->connect_error);
        }
        // $servername = "localhost";
        // $username_db = "root";
        // $password_db = "";
        // $dbname = "pregnentdb";

        // $conn = new mysqli($servername, $username_db, $password_db, $dbname);

        // if ($conn->connect_error) {
        //     die("Connection failed: " . $conn->connect_error);
        // }

        // Query to retrieve the last 5 'total' values for the given username
        $sql = "SELECT mood_insert
        FROM mood
        WHERE username = '$username'
        ORDER BY date_insert DESC";
        $result = $conn->query($sql);

        if ($result->num_rows > 0) {
            // Fetch all 'total' values into an array
            $totals = array();
            while ($row = $result->fetch_assoc()) {
                $totals[] = $row['mood_insert'];
            }

            // Prepare the response
            
            $response = $totals;
        } else {
            // No records found
            $response['status'] = 'failure';
            $response['message'] = 'No data found for the given username';
        }

        // Close the database connection
        $conn->close();
    } else {
        $response['status'] = 'failure';
        $response['message'] = 'Username not provided';
    }

    // Send the JSON-encoded response
    echo json_encode($response);
}
