
<?php

if ($_SERVER["REQUEST_METHOD"] == "POST") {
    // Decode the JSON data
    $json = file_get_contents('php://input');
    $data = json_decode($json, true);

    if (isset($_POST["userId"])) {

        $userId = $_POST["userId"];

        // Establish the database connection
        require("conn.php");

        // Check connection
        if ($conn->connect_error) {
            die("Connection failed: " . $conn->connect_error);
        }
        // $servername = "localhost";
        // $username_db = "root";
        // $password_db = "";
        // $dbname = "pregnentdb";

        // $conn = new mysqli($servername, $username_db, $password_db, $dbname);

        // if ($conn->connect_error) {
        //     die("Connection failed: " . $conn->connect_error);
        // }


// Assuming you have a table named 'users' with columns: 
// id, username, password, firstname, lastname, age, gender, height, weight, bloodgroup, contact
        $sql = "SELECT firstname ,lastname ,age ,address, username , password, contact FROM addpatient WHERE username = '$userId'"; // Assuming you are fetching details for user with id 1

        $result = $conn->query($sql);

        if ($result->num_rows > 0) {
        // Output data of each row
        $row = $result->fetch_assoc();
        $userData = array(
            'username' => $row['username'],
            'password' => $row['password'],
            'firstname' => $row['firstname'],
            'lastname' => $row['lastname'],
            'age' => $row['age'],
            'address' => $row['address'],
            'contact' => $row['contact']
        );
        echo json_encode($userData);
        } else {
        echo "0 results";
        }
        $conn->close();
    } else {
        echo "not connected";
    }
}

?>
