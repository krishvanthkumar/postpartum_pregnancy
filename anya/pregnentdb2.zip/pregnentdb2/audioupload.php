<?php

require("conn.php");

// Check connection
if ($conn->connect_error) {
    die("Connection failed: " . $conn->connect_error);
}

// Set target directory relative to the project root
$target_dir = "uploads/"; // Relative directory for uploads
$allowed_extensions = array("mp3", "wav", "ogg"); // Allowed file extensions

error_reporting(E_ALL);
ini_set('display_errors', 1);

$additionalData = $_POST['additional_data'];

// Check if a file was uploaded
if (isset($_FILES["audio"]["name"])) {

    // Get file information
    $filename = $_FILES["audio"]["name"];
    $filesize = $_FILES["audio"]["size"];
    $temp_name = $_FILES["audio"]["tmp_name"];
    $error = $_FILES["audio"]["error"];

    // Check for errors
    if ($error !== UPLOAD_ERR_OK) {
        echo "Error uploading file: " . $error;
    } else {

        // Check file extension
        $file_ext = strtolower(pathinfo($filename, PATHINFO_EXTENSION));
        if (!in_array($file_ext, $allowed_extensions)) {
            echo "Invalid file type. Only " . implode(', ', $allowed_extensions) . " allowed.";
        } else {

            // Check file size
            if ($filesize > 50000000) { // 50MB limit
                echo "File size exceeds limit.";
            } else {

                // Generate a unique file name
                $new_filename = uniqid() . "." . $file_ext;

                // Ensure the uploads directory exists
                if (!is_dir($target_dir)) {
                    mkdir($target_dir, 0777, true);
                }

                // Move the uploaded file to the target directory
                if (move_uploaded_file($temp_name, $target_dir . $new_filename)) {
                    // Prepare SQL statement to insert data into the table
                    $filepath = $target_dir . $new_filename;
                    $sql = "INSERT INTO audios (filename, filepath, uploaded_at) VALUES ('$additionalData', '$filepath', CURRENT_TIMESTAMP)";
                    
                    // Execute the SQL statement
                    if ($conn->query($sql) === TRUE) {
                        echo "File uploaded successfully.";
                    } else {
                        echo "Error: " . $sql . "<br>" . $conn->error;
                    }
                } else {
                    echo "Error moving uploaded file.";
                }
            }
        }
    }
} else {
    echo "No file selected.";
}

?>
