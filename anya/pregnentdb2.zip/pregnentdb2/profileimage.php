<?php

if ($_SERVER["REQUEST_METHOD"] == "POST") {
    // Decode the JSON data
    $json = file_get_contents('php://input');
    $data = json_decode($json, true);

    if (isset($_POST["username"])) {
        $username = $_POST["username"];

        // Establish the database connection
        require("conn.php");

        // Check connection
        if ($conn->connect_error) {
            die("Connection failed: " . $conn->connect_error);
        }

        // Query to check login credentials
        $sql = "SELECT dp FROM addpatient WHERE username = '$username'";
        $result = $conn->query($sql);

        if ($result->num_rows > 0) {
            // Fetch the data
            $row = $result->fetch_assoc();
            $profileImage = $row['dp'];

            if (!empty($profileImage)) {
                // Assume $profileImage contains a relative path to the image
                 // Replace with your server's URL
                $imageUrl = $profileImage;

                // Return JSON with image URL
                header('Content-Type: application/json');
                echo json_encode(['profile_image_url' => $imageUrl]);
            } else {
                // If profile image not found or empty, send a default URL
                $defaultUrl = "http://your-server.com/default-profile.jpg";
                echo json_encode(['profile_image_url' => $defaultUrl]);
            }
        } else {
            // If no matching user found, send an error response
            header('Content-Type: application/json');
            echo json_encode(['error' => 'User not found']);
        }

        // Close the database connection
        $conn->close();
    } else {
        // If username not provided, send an error response
        header('Content-Type: application/json');
        echo json_encode(['error' => 'Username not provided']);
    }
}
?>
