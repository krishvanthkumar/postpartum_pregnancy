<?php
// Database connection details
require("conn.php");

// Check connection
if ($conn->connect_error) {
    die("Connection failed: " . $conn->connect_error);
}

// Get video ID from the POST data
$vid = $_POST['vid'];

// Fetch video path from the database based on the username
$sql = "SELECT video_one FROM meditation WHERE vid = '$vid'";
$result = $conn->query($sql);

if ($result->num_rows > 0) {
    $row = $result->fetch_assoc();
    $videoPath = $row['video_one'];

    // Return the video path as JSON
    echo json_encode(['video_path' => $videoPath]);
} else {
    echo json_encode(['error' => 'Video not found for the given username']);
}

$conn->close();
?>