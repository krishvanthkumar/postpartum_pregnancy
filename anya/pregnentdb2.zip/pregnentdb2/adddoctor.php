<?php
//include con.php;
if ($_SERVER["REQUEST_METHOD"] == "POST") {
    // Decode the JSON data
    $json = file_get_contents('php://input');
    $data = json_decode($json, true);

    if (isset($_POST["username"]) && isset($_POST["password"])){
        $username = $_POST["username"];
        $password = $_POST["password"];
        $name = $_POST["name"];
        $age = $_POST["age"];
        $gender = $_POST["gender"];
        $contact = $_POST["contact"];
        $specialist = $_POST["specialist"];
        
        require("conn.php");

        // Check connection
        if ($conn->connect_error) {
            die("Connection failed: " . $conn->connect_error);
        }
        // Establish the database connection
        // $servername = "localhost";
        // $username_db = "root";
        // $password_db = "";
        // $dbname = "pregnentdb";

        // $conn = new mysqli($servername, $username_db, $password_db, $dbname);

        // if ($conn->connect_error) {
        //     die("Connection failed: " . $conn->connect_error);
        // }

        // Query to insert data into the database
        $sql = "INSERT INTO dlogin (username, password, name, contact, age, gender, specialist) VALUES ('$username', '$password', '$name', '$contact', '$age', '$gender', '$specialist' )";
       
        $a = $conn->query($sql);
        
        if ($a === TRUE ) {
            $response['status'] = 'success';
            $response['message'] = 'Data inserted successfully';
        } else {
            $response['status'] = 'failure';
            $response['error'] = $conn->error;
        }

        // Close the database connection
        $conn->close();
    } else {
        $response['status'] = 'failure';}}