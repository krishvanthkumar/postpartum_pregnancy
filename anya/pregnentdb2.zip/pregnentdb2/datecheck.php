
<?php

if ($_SERVER["REQUEST_METHOD"] == "POST") {
    // Decode the JSON data
    $json = file_get_contents('php://input');
    $data = json_decode($json, true);

    if (isset($_POST["username"])) {

        $username = $_POST["username"];

        // Establish the database connection
        require("conn.php");

        // Check connection
        if ($conn->connect_error) {
            die("Connection failed: " . $conn->connect_error);
        }
        // $servername = "localhost";
        // $username_db = "root";
        // $password_db = "";
        // $dbname = "pregnentdb";

        // $conn = new mysqli($servername, $username_db, $password_db, $dbname);

        // if ($conn->connect_error) {
        //     die("Connection failed: " . $conn->connect_error);
        // }

        // Query to check login credentials
        $sql = "SELECT 
        mood_insert, 
        feel_interaction, 
        sleep_rateing, 
        time_kid,
        date_insert AS latest_date,
        username
        FROM 
        mood
        WHERE 
        username = '$username'
        ORDER BY 
        date_insert DESC
        LIMIT 1;";

        $result = $conn->query($sql);

        if ($result->num_rows > 0) {
            // Fetch the data
            $row = $result->fetch_assoc();

            // Extract the values you need and concatenate them into a string
            $string_data = $row['latest_date'] . ', ' . $row['time_kid'] . ', ' . $row['mood_insert'] . ', ' . $row['feel_interaction']. ', ' . $row['sleep_rateing']. ', ' . $row['username']   ;

            // Login successful
        
            $response = $string_data;
        } else {
            // Login failed
            $response = '0';
            
        }

        // Close the database connection
        $conn->close();
    } else {
        $response['status'] = 'failure';
        $response['message'] = 'Username or password not provided';
    }

    echo json_encode($response);
}