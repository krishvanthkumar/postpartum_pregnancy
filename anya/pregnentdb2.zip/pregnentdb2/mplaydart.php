<?php
require("conn.php");

// Check connection
if ($conn->connect_error) {
    die("Connection failed: " . $conn->connect_error);
}

// Check if the video ID is provided
if (isset($_POST['id'])) {
    $videoId = $_POST['id'];

    // Fetch video filepath from the database based on the provided ID
    $sql = "SELECT video_one FROM meditation WHERE vid = $videoId";
    $result = $conn->query($sql);

    if ($result->num_rows > 0) {
        // Output video file path as JSON
        $row = $result->fetch_assoc();
        $videoFilePath = $row['video_one'];

        // Return the video URL in JSON format
        echo  $videoFilePath;
    } else {
        echo  "Video not found.";
    }
} else {
    echo  "Video ID not provided.";
}
?>
