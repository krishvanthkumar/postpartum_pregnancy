<?php
if ($_SERVER["REQUEST_METHOD"] == "POST") {
    // Decode the JSON data
    $json = file_get_contents('php://input');
    $data = json_decode($json, true);

    if (isset($_POST["username"]) && isset($_POST["mdate"])) {
        $username = $_POST["username"];
        $mdate = $_POST["mdate"];
        $feel = $_POST["feel"];
        $cmt = $_POST["cmt"];

        // Establish the database connection
        require("conn.php");

        // Check connection
        if ($conn->connect_error) {
            die("Connection failed: " . $conn->connect_error);
        }
        // $servername = "localhost";
        // $username_db = "root";
        // $password_db = "";
        // $dbname = "pregnentdb";

        // $conn = new mysqli($servername, $username_db, $password_db, $dbname);

        // if ($conn->connect_error) {
        //     die("Connection failed: " . $conn->connect_error);
        // }

        // Check if the combination of username and date exists
        $checkIfExistsSql = "SELECT * FROM mood WHERE username = '$username' AND date_insert = '$mdate'";
        $result = $conn->query($checkIfExistsSql);

        if ($result && $result->num_rows > 0) {
            // Update the existing record
            $updateSql = "UPDATE mood SET feel_interaction = '$feel', cmt_interaction = '$cmt' WHERE username = '$username' AND date_insert = '$mdate'";
            if ($conn->query($updateSql) === TRUE) {
                $response['status'] = 'success';
                $response['message'] = 'Data updated successfully';
            } else {
                $response['status'] = 'failure';
                $response['error'] = $conn->error;
            }
        } else {
            // Insert a new record
            $insertSql = "INSERT INTO mood (username, date_insert, feel_interaction, cmt_interaction) VALUES ('$username', '$mdate', '$feel', '$cmt')";
            if ($conn->query($insertSql) === TRUE) {
                $response['status'] = 'success';
                $response['message'] = 'Data inserted successfully';
            } else {
                $response['status'] = 'failure';
                $response['error'] = $conn->error;
            }
        }

        // Close the database connection
        $conn->close();
    } else {
        $response['status'] = 'failure';
        $response['message'] = 'Username or date not provided';
    }

    echo json_encode($response);
    error_reporting(E_ALL);
    ini_set('display_errors', 1);
}
?>
