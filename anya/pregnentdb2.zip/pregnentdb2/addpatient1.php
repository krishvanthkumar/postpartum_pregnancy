<?php
// Enable error reporting for debugging
ini_set('display_errors', 1);
ini_set('display_startup_errors', 1);
error_reporting(E_ALL);

if ($_SERVER["REQUEST_METHOD"] == "POST") {
    // Decode the JSON data
    $json = file_get_contents('php://input');
    $data = json_decode($json, true);

    if (isset($data["password"])) {
        $password = $data["password"];
        $firstname = $data["firstname"];
        $lastname = $data["lastname"];
        $contact = $data["contact"];
        $age = $data["age"];
        $dowo = $data["dowo"];
        $address = $data["address"];
        $informant = $data["informant"];
        $informant_related = $data["informant_related"];
        $educational_history = $data["educational_history"];
        $occupational_history = $data["occupational_history"];
        $religion = $data["religion"];
        $date_of_first_visit_to_smch = $data["date_of_first_visit_to_smch"];
        $date_of_delivery = $data["date_of_delivery"];
        $granida = $data["granida"];
        $para = $data["para"];
        $live_children = $data["live_children"];
        $abortion = $data["abortion"];
        $ectogic = $data["ectogic"];
        $lmp = $data["lmp"];
        $cedd = $data["cedd"];
        $risk_factor = $data["risk_factor"];
        $stressors = $data["stressors"];
        $relevant_psychiatric_family_history = $data["relevant_psychiatric_family_history"];
        $detail_of_family_history = $data["detail_of_family_history"];
        $antenatal_visits = $data["antenatal_visits"];
        $conception = $data["conception"];
        $present_obstetric_history = $data["present_obstetric_history"];
        $s_past_obstetric_history = $data["s_past_obstetric_history"];
        $s_outcome = $data["s_outcome"];
        $s_detail_of_abortion = $data["s_detail_of_abortion"];
        $s_detail_of_ad = $data["s_detail_of_ad"];
        $s_delivery_details = $data["s_delivery_details"];
        $s_complication = $data["s_complication"];
        $s_baby_details = $data["s_baby_details"];
        $t_past_obstetric_history = $data["t_past_obstetric_history"];
        $t_outcome = $data["t_outcome"];
        $t_detail_of_abortion = $data["t_detail_of_abortion"];
        $t_detail_of_ad = $data["t_detail_of_ad"];
        $t_delivery_details = $data["t_delivery_details"];
        $t_complication = $data["t_complication"];
        $t_baby_details = $data["t_baby_details"];
        $dp = $data["dp"];
        $post_natal_period = $data["post_natal_period"];
        $past_medical_history = $data["past_medical_history"];
        $details_of_past_surgeries = $data["details_of_past_surgeries"];
        $personal_history = $data["personal_history"];
        $sleep_pattern = $data["sleep_pattern"];
        $history_of_hospital_adm = $data["history_of_hospital_adm"];
        $diagnosis = $data["diagnosis"];
        $sdate = date("Y-m-d"); // Assuming the date_insert is the current date

        // Establish the database connection using mysqli
        require("con.php");

        // Check connection
        if ($conn->connect_error) {
            die("Connection failed: " . $conn->connect_error);
        }

        // Auto-generate username
        $result = $conn->query("SELECT COUNT(*) AS count FROM addpatient");
        $row = $result->fetch_assoc();
        $count = $row['count'] + 1;
        $username = "SMCU" . str_pad($count, 3, '0', STR_PAD_LEFT);

        // Calculate EDD
        $lmp_date = new DateTime($lmp);
        $edd_date = $lmp_date->add(new DateInterval('P280D'));
        $edd = $edd_date->format('Y-m-d');

        // Query to insert data into the database
        $sql = "INSERT INTO addpatient (
            sno, firstname, lastname, age, daughterofwifeof, address, username, password, contact, informant, 
            informant_related, educational_history, occupation_history, religion, date_of_first_visit_to_smch, 
            date_of_delivery, granida, para, live_children, abortion, ectogic, lmp, edd, cedd, risk_factor, 
            stressors, relevant_psychiatric_family_history, Details_of_family_history, antenatal_visits, conception, 
            present_obstetric_history, s_past_obstetric_history, s_outcome, s_detail_of_abortion, s_detail_of_a_d, 
            s_delivery_details, s_complication, s_baby_details, t_past_obstetric_history, t_outcome, t_detail_of_abortion, 
            t_detail_of_a_d, t_delivery_details, t_complication, t_baby_details, dp, post_natal_period, past_medical_history, 
            details_of_past_surgeries, personal_history, sleep_pattern, history_of_hospital_adm, diagnosis
        ) VALUES (
            NULL, '$firstname', '$lastname', '$age', '$dowo', '$address', '$username', '$password', '$contact', '$informant', 
            '$informant_related', '$educational_history', '$occupational_history', '$religion', '$date_of_first_visit_to_smch', 
            '$date_of_delivery', '$granida', '$para', '$live_children', '$abortion', '$ectogic', '$lmp', '$edd', '$cedd', 
            '$risk_factor', '$stressors', '$relevant_psychiatric_family_history', '$detail_of_family_history', 
            '$antenatal_visits', '$conception', '$present_obstetric_history', '$s_past_obstetric_history', '$s_outcome', 
            '$s_detail_of_abortion', '$s_detail_of_ad', '$s_delivery_details', '$s_complication', '$s_baby_details', 
            '$t_past_obstetric_history', '$t_outcome', '$t_detail_of_abortion', '$t_detail_of_ad', '$t_delivery_details', 
            '$t_complication', '$t_baby_details', '$dp', '$post_natal_period', '$past_medical_history', '$details_of_past_surgeries', 
            '$personal_history', '$sleep_pattern', '$history_of_hospital_adm', '$diagnosis'
        )";

        if ($conn->query($sql) === TRUE) {
            $sql_mood = "INSERT INTO mood (username, date_insert) VALUES ('$username', '$sdate')";
            
            if($conn->query($sql_mood)===True){
                
                $response['status'] = 'success';
                $response['message'] = 'Data inserted successfully';
            }
            else{
                $response['status'] = 'fail to add in mood';
                $response['error'] = $conn->error;
            }
        } else {
            $response['status'] = 'failure';
            $response['error'] = $conn->error;
        }

        // Close the database connection
        $conn->close();
    } else {
        $response['status'] = 'failure';
        $response['error'] = 'Missing required parameters';
    }

    echo json_encode($response);
}
?>
