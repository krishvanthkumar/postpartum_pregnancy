<?php
// Database connection details
require("conn.php");

// Check connection
if ($conn->connect_error) {
    die("Connection failed: " . $conn->connect_error);
}

// Directory where uploaded videos will be saved (relative path)
$uploadDir = "videos/";

if ($_SERVER['REQUEST_METHOD'] == 'POST' && isset($_FILES['uploaded_file'])) {
    
    $file = $_FILES['uploaded_file'];
    $filename = isset($_POST['video_title']) ? $_POST['video_title'] : '';
    
    $fileName = basename($file['name']);
    $uploadPath = $uploadDir . $fileName;
    
    // Ensure the upload directory exists
    if (!is_dir($uploadDir)) {
        mkdir($uploadDir, 0777, true);
    }
    
    // Move the uploaded file to the specified directory
    if (move_uploaded_file($file['tmp_name'], $uploadPath)) {
        // File uploaded successfully, insert path into database
        $sql = "INSERT INTO pregvideo (video_title, video_one) VALUES (?, ?)";

        // Prepare the SQL statement
        $stmt = $conn->prepare($sql);
        if (!$stmt) {
            die("Error preparing SQL statement: " . $conn->error);
        }

        // Bind parameters to the prepared statement
        $stmt->bind_param("ss", $filename, $uploadPath);

        // Execute the statement
        if ($stmt->execute()) {
            echo "Video path inserted into the database successfully";
        } else {
            echo "Error inserting video path into the database: " . $stmt->error;
        }

        // Close the statement
        $stmt->close();
    } else {
        echo "Error uploading the file";
    }
    
} else {
    echo "Invalid request";
}

// Close connection
$conn->close();
?>
