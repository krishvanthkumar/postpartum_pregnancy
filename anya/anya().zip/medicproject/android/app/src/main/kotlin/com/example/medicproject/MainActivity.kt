package com.simats.medicproject

import io.flutter.embedding.android.FlutterActivity

class MainActivity: FlutterActivity()
