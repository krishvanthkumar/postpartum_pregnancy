import 'dart:convert';

import 'package:flutter/material.dart';
import 'package:http/http.dart' as http;
import 'package:intl/intl.dart';
import 'package:medicproject/common.dart';
import 'package:multi_select_flutter/multi_select_flutter.dart';

class Register1 extends StatefulWidget {
  @override
  _Register1State createState() => _Register1State();
}

class _Register1State extends State<Register1> {
  String username = 'will be auto generated';
  String password = '';
  String fname = '';
  String lname = '';
  String contact = '';
  String age = '';
  String dowo = '';
  String address = '';
  String informant = '';
  String informantRelated = '';
  String educationalHistory = '';
  String occupationalHistory = '';
  String religion = '';
  String dateOfFirstVisit = '';
  String dateOfDelivery = '';
  String granida = '';
  String para = '';
  String live_children = '';
  String abortion = '';
  String ectogic = '';
  String lmp = '';
  String edd = '';
  String cedd = '';
  String riskFactor = '';
  String stressors = '';
  String relevantPsychiatricFamilyHistory = '';
  String detailOfFamilyHistory = '';
  String antenatalVisits = '';
  String conception = '';
  String present_obstetric_history = '';

  bool sPastObstetricHistory = false;
  String sOutcome = '';
  String sDetailOfAbortion = '';
  String sDetailOfAD = '';
  String sDeliveryDetails = '';
  String sComplication = '';
  String sBabyDetails = '';

  bool tPastObstetricHistory = false;
  String tOutcome = '';
  String tDetailOfAbortion = '';
  String tDetailOfAD = '';
  String tDeliveryDetails = '';
  String tComplication = '';
  String tBabyDetails = '';

  String post_natal_period = '';
  String past_medical_history = '';
  String details_of_past_surgeries = '';
  String personal_history = '';
  String sleep_pattern = '';
  String history_of_hospital_adm = '';
  String diagnosis = '';

  List<String> informantOptions = [
    'Reliable',
    'Not-reliable',
    'Adequate',
    'Inadequate',
    'Consistent',
    'Not consistent'
  ];
  List<String> informantRelatedOptions = [
    'Partner',
    'Parents',
    'Inlaws',
    'Close friends',
    'Siblings',
    'Guardian'
  ];
  List<String> educationalHistoryOptions = [
    'Uneducated',
    'Below 8',
    'Below 10',
    'Below 12',
    'UG',
    'PG',
    'Post PG'
  ];
  List<String> occupationalHistoryOptions = [
    'Unemployed',
    'Professional',
    'Skilled worker',
    'Semi-skilled worker'
  ];
  List<String> riskFactorOptions = [
    'GDM',
    'GMTN',
    'Heart disease complication pregnancy',
    'Previous cesarean section',
    'Preterm',
    'Congenital malformations',
    'RH negative pregnancy',
    'Thyroid disorders',
    'Psychiatric illness',
    'Autoimmune',
    'Connective tissue disorders',
    'Multiple pregnancy'
  ];
  List<String> stressorsOptions = [
    'Nil',
    'Interpersonal conflicts',
    'Financial',
    'Family issues',
    'Professional',
    'Child birth related',
    'New born concerns',
    'Life events',
    'Others'
  ];

  final GlobalKey<FormState> _formKey = GlobalKey<FormState>();

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      appBar: AppBar(
        title: Text('Register'),
      ),
      body: SingleChildScrollView(
        child: Padding(
          padding: const EdgeInsets.all(20.0),
          child: Form(
            key: _formKey,
            child: Column(
              crossAxisAlignment: CrossAxisAlignment.center,
              children: [
                _buildTextField('Username', (value) {
                  setState(() {
                    username = value;
                  });
                }, readOnly: true, initialValue: username),
                _buildTextField('Password', (value) {
                  setState(() {
                    password = value;
                  });
                }, obscureText: true),
                _buildTextField('First Name', (value) {
                  setState(() {
                    fname = value;
                  });
                }),
                _buildTextField('Last Name', (value) {
                  setState(() {
                    lname = value;
                  });
                }),
                _buildTextField('Age', (value) {
                  setState(() {
                    age = value;
                  });
                }),
                _buildTextField('Daughter of/ Wife of', (value) {
                  setState(() {
                    dowo = value;
                  });
                }),
                _buildTextField('Address', (value) {
                  setState(() {
                    address = value;
                  });
                }),
                _buildTextField('Contact', (value) {
                  setState(() {
                    contact = value;
                  });
                }),
                _buildMultiChoice('Informant', informantOptions, (value) {
                  setState(() {
                    informant = value.join(',');
                  });
                }),
                _buildRadioButton('Informant Related', informantRelatedOptions,
                    informantRelated, (value) {
                  setState(() {
                    informantRelated = value!;
                  });
                }),
                _buildRadioButton('Educational History',
                    educationalHistoryOptions, educationalHistory, (value) {
                  setState(() {
                    educationalHistory = value!;
                  });
                }),
                _buildRadioButton('Occupational History',
                    occupationalHistoryOptions, occupationalHistory, (value) {
                  setState(() {
                    occupationalHistory = value!;
                  });
                }),
                _buildTextField('Religion', (value) {
                  setState(() {
                    religion = value;
                  });
                }),
                _buildDatePicker('Date of First Visit to SMCH', (value) {
                  setState(() {
                    dateOfFirstVisit = value;
                  });
                }),
                _buildDatePicker('Date of Delivery', (value) {
                  setState(() {
                    dateOfDelivery = value;
                  });
                }),
                _buildTextField('Granida', (value) {
                  setState(() {
                    granida = value;
                  });
                }),
                _buildTextField('Para', (value) {
                  setState(() {
                    para = value;
                  });
                }),
                _buildTextField('Live children', (value) {
                  setState(() {
                    live_children = value;
                  });
                }),
                _buildTextField('Abortion', (value) {
                  setState(() {
                    abortion = value;
                  });
                }),
                _buildTextField('Ectogic', (value) {
                  setState(() {
                    ectogic = value;
                  });
                }),
                _buildDatePicker('LMP', (value) {
                  setState(() {
                    lmp = value;
                    edd = calculateEDD(value);
                  });
                }),
                _buildDatePicker('EDD', (value) {
                  setState(() {
                    edd = value;
                  });
                }, initialValue: edd, readOnly: true),
                _buildDatePicker('CEDD', (value) {
                  setState(() {
                    cedd = value;
                  });
                }),
                _buildMultiChoice('Risk Factor', riskFactorOptions, (value) {
                  setState(() {
                    riskFactor = value.join(',');
                  });
                }),
                _buildMultiChoice('Stressors', stressorsOptions, (value) {
                  setState(() {
                    stressors = value.join(',');
                  });
                }),
                _buildRadioButton(
                    'Relevant Psychiatric Family History',
                    ['Present', 'Absent'],
                    relevantPsychiatricFamilyHistory, (value) {
                  setState(() {
                    relevantPsychiatricFamilyHistory = value!;
                  });
                }),
                _buildTextField('Detail of family history', (value) {
                  setState(() {
                    detailOfFamilyHistory = value;
                  });
                }),
                _buildTextField('Antenatal visits', (value) {
                  setState(() {
                    antenatalVisits = value;
                  });
                }),
                _buildTextField('Conception', (value) {
                  setState(() {
                    conception = value;
                  });
                }),
                _buildTextField('Present obstetric history', (value) {
                  setState(() {
                    present_obstetric_history = value;
                  });
                }),
                _buildRadioButton(
                    'Past obstetric history - 1 pregnancy',
                    ['Yes', 'No'],
                    sPastObstetricHistory ? 'Yes' : 'No', (value) {
                  setState(() {
                    sPastObstetricHistory = value == 'Yes';
                  });
                }),
                if (sPastObstetricHistory) _buildObstetricHistorySection1(),
                _buildRadioButton(
                    'Past obstetric history - 2 pregnancies',
                    ['Yes', 'No'],
                    tPastObstetricHistory ? 'Yes' : 'No', (value) {
                  setState(() {
                    tPastObstetricHistory = value == 'Yes';
                  });
                }),
                if (tPastObstetricHistory) _buildObstetricHistorySection2(),
                _buildTextField('Post natal period', (value) {
                  setState(() {
                    post_natal_period = value;
                  });
                }),
                _buildTextField('Past medical history', (value) {
                  setState(() {
                    past_medical_history = value;
                  });
                }),
                _buildTextField('Details of past surgeries', (value) {
                  setState(() {
                    details_of_past_surgeries = value;
                  });
                }),
                _buildTextField('Personal history', (value) {
                  setState(() {
                    personal_history = value;
                  });
                }),
                _buildTextField('Sleep pattern', (value) {
                  setState(() {
                    sleep_pattern = value;
                  });
                }),
                _buildTextField('History of hospital admission', (value) {
                  setState(() {
                    history_of_hospital_adm = value;
                  });
                }),
                _buildTextField('Diagnosis', (value) {
                  setState(() {
                    diagnosis = value;
                  });
                }),
                SizedBox(height: 20.0),
                ElevatedButton(
                  onPressed: _sendDataToServer,
                  child: Text('Submit'),
                ),
              ],
            ),
          ),
        ),
      ),
    );
  }

  Widget _buildTextField(String label, Function(String) onChanged,
      {bool obscureText = false,
      bool readOnly = false,
      String initialValue = ''}) {
    return TextFormField(
      initialValue: initialValue,
      readOnly: readOnly,
      obscureText: obscureText,
      decoration: InputDecoration(labelText: label),
      onChanged: onChanged,
    );
  }

  Widget _buildMultiChoice(
      String label, List<String> options, Function(List<String>) onConfirm) {
    return MultiSelectDialogField(
      items: options.map((e) => MultiSelectItem(e, e)).toList(),
      title: Text(label),
      onConfirm: onConfirm,
    );
  }

  Widget _buildRadioButton(String label, List<String> options,
      String? groupValue, Function(String?) onChanged) {
    return Column(
      crossAxisAlignment: CrossAxisAlignment.start,
      children: [
        Text(label),
        Column(
          children: options.map((option) {
            return Row(
              children: [
                Radio<String>(
                  value: option,
                  groupValue: groupValue,
                  onChanged: onChanged,
                ),
                Text(option),
              ],
            );
          }).toList(),
        ),
      ],
    );
  }

  Widget _buildDatePicker(String label, Function(String) onChanged,
      {String? initialValue, bool readOnly = false}) {
    TextEditingController controller = TextEditingController();
    if (initialValue != null) {
      controller.text = initialValue;
    }

    return TextFormField(
      controller: controller,
      readOnly: readOnly,
      decoration: InputDecoration(labelText: label),
      onTap: () async {
        if (readOnly) return;
        DateTime? pickedDate = await showDatePicker(
          context: context,
          initialDate: DateTime.now(),
          firstDate: DateTime(1900),
          lastDate: DateTime(2101),
        );
        if (pickedDate != null) {
          String formattedDate = DateFormat('yyyy-MM-dd').format(pickedDate);
          controller.text = formattedDate;
          onChanged(formattedDate);
        }
      },
    );
  }

  String calculateEDD(String lmp) {
    DateTime lmpDate = DateFormat('yyyy-MM-dd').parse(lmp);
    DateTime eddDate = lmpDate.add(Duration(days: 280));
    return DateFormat('yyyy-MM-dd').format(eddDate);
  }

  Widget _buildObstetricHistorySection1() {
    return Column(
      children: [
        _buildTextField('Outcome', (value) {
          setState(() {
            sOutcome = value;
          });
        }),
        _buildTextField('Detail of abortion', (value) {
          setState(() {
            sDetailOfAbortion = value;
          });
        }),
        _buildTextField('Detail of AD', (value) {
          setState(() {
            sDetailOfAD = value;
          });
        }),
        _buildTextField('Delivery details', (value) {
          setState(() {
            sDeliveryDetails = value;
          });
        }),
        _buildTextField('Complication', (value) {
          setState(() {
            sComplication = value;
          });
        }),
        _buildTextField('Baby details', (value) {
          setState(() {
            sBabyDetails = value;
          });
        }),
      ],
    );
  }

  Widget _buildObstetricHistorySection2() {
    return Column(
      children: [
        _buildTextField('Outcome', (value) {
          setState(() {
            tOutcome = value;
          });
        }),
        _buildTextField('Detail of abortion', (value) {
          setState(() {
            tDetailOfAbortion = value;
          });
        }),
        _buildTextField('Detail of AD', (value) {
          setState(() {
            tDetailOfAD = value;
          });
        }),
        _buildTextField('Delivery details', (value) {
          setState(() {
            tDeliveryDetails = value;
          });
        }),
        _buildTextField('Complication', (value) {
          setState(() {
            tComplication = value;
          });
        }),
        _buildTextField('Baby details', (value) {
          setState(() {
            tBabyDetails = value;
          });
        }),
      ],
    );
  }

  Future<void> _sendDataToServer() async {
    if (!_formKey.currentState!.validate()) {
      return;
    }

    final body = {
      'username': username,
      'password': password,
      'firstname': fname,
      'lastname': lname,
      'contact': contact,
      'age': age,
      'dowo': dowo,
      'address': address,
      'informant': informant,
      'informant_related': informantRelated,
      'educational_history': educationalHistory,
      'occupational_history': occupationalHistory,
      'religion': religion,
      'date_of_first_visit_to_smch':
          dateOfFirstVisit.isEmpty ? null : dateOfFirstVisit,
      'date_of_delivery': dateOfDelivery.isEmpty ? null : dateOfDelivery,
      'granida': granida,
      'para': para,
      'live_children': live_children,
      'abortion': abortion,
      'ectogic': ectogic,
      'lmp': lmp,
      'edd': edd,
      'cedd': cedd,
      'risk_factor': riskFactor,
      'stressors': stressors,
      'relevant_psychiatric_family_history': relevantPsychiatricFamilyHistory,
      'detail_of_family_history': detailOfFamilyHistory,
      'antenatal_visits': antenatalVisits,
      'conception': conception,
      'present_obstetric_history': present_obstetric_history,
      's_past_obstetric_history': sPastObstetricHistory ? 'Yes' : 'No',
      's_outcome': sOutcome,
      's_detail_of_abortion': sDetailOfAbortion,
      's_detail_of_ad': sDetailOfAD,
      's_delivery_details': sDeliveryDetails,
      's_complication': sComplication,
      's_baby_details': sBabyDetails,
      't_past_obstetric_history': tPastObstetricHistory ? 'Yes' : 'No',
      't_outcome': tOutcome,
      't_detail_of_abortion': tDetailOfAbortion,
      't_detail_of_ad': tDetailOfAD,
      't_delivery_details': tDeliveryDetails,
      't_complication': tComplication,
      't_baby_details': tBabyDetails,
      'post_natal_period': post_natal_period,
      'past_medical_history': past_medical_history,
      'details_of_past_surgeries': details_of_past_surgeries,
      'personal_history': personal_history,
      'sleep_pattern': sleep_pattern,
      'history_of_hospital_adm': history_of_hospital_adm,
      'diagnosis': diagnosis,
    };

    final headers = {'Content-Type': 'application/json'};

    try {
      final response = await http.post(
        Uri.parse(addpatient1uri),
        headers: headers,
        body: json.encode(body),
      );

      if (response.statusCode == 200) {
        print('Data sent successfully: ${response.body}');
        showDialog(
          context: context,
          builder: (BuildContext context) {
            return AlertDialog(
              title: Text('Success'),
              content: Text('Data submitted successfully!'),
              actions: [
                TextButton(
                  child: Text('OK'),
                  onPressed: () {
                    Navigator.of(context).pop(); // Close the dialog
                    Navigator.of(context)
                        .pop(); // Navigate back to previous page
                  },
                ),
              ],
            );
          },
        );
      } else {
        print('Server error: ${response.body}');
        showDialog(
          context: context,
          builder: (BuildContext context) {
            return AlertDialog(
              title: Text('Error'),
              content: Text('Failed to submit data: ${response.body}'),
              actions: [
                TextButton(
                  child: Text('OK'),
                  onPressed: () {
                    Navigator.of(context).pop(); // Close the dialog
                  },
                ),
              ],
            );
          },
        );
      }
    } catch (e) {
      print('Error: $e');
      showDialog(
        context: context,
        builder: (BuildContext context) {
          return AlertDialog(
            title: Text('Error'),
            content: Text('An error occurred: $e'),
            actions: [
              TextButton(
                child: Text('OK'),
                onPressed: () {
                  Navigator.of(context).pop(); // Close the dialog
                },
              ),
            ],
          );
        },
      );
    }
  }
}
