//String ip = "14.139.187.229:8081";
String ip = "192.168.22.150:80";
//String ip = "192.168.0.107:80";
//patient
String loginUri = "http://" + ip + "/pregnentdb2/patientlogin.php";
String chaturi = "http://" + ip + "/pregnentdb2/chatbot.php";
String questionuri = "http://" + ip + "/pregnentdb2/testcalflutter.php";
String mooduri = "http://" + ip + "/pregnentdb2/mood.php";
String sleepuri = "http://" + ip + "/pregnentdb2/sleep.php";
String mamameuri = "http://" + ip + "/pregnentdb2/mamame.php";
String interactionuri = "http://" + ip + "/pregnentdb2/interaction.php";
String profileuri = "http://" + ip + "/pregnentdb2/profile.php";
String checkuri = "http://" + ip + "/pregnentdb2/datecheck.php";
String testcheckuri = "http://" + ip + "/pregnentdb2/testtime.php";
String moodtrackuri = "http://" + ip + "/pregnentdb2/graphdata2.php";
String sleeptrackuri = "http://" + ip + "/pregnentdb2/graphdata1.php";
String testtrackuri = "http://" + ip + "/pregnentdb2/graphdata.php";
String audiolisturi = "http://" + ip + "/pregnentdb2/audiolist.php";
String audioplayuri = "http://" + ip + "/pregnentdb2/audioplaydart.php";
String videolisturi = "http://" + ip + "/pregnentdb2/videolist.php";
String videoplayuri = "http://" + ip + "/pregnentdb2/videoplaydart.php";
String medlisturi = "http://" + ip + "/pregnentdb2/mlist.php";
String medplayuri = "http://" + ip + "/pregnentdb2/mplaydart.php";
String profilepageuri = "http://" + ip + "/pregnentdb2/profiledart.php";
String profileimguri = "http://" + ip + "/pregnentdb2/profileimage.php";
String uploadimguri = "http://" + ip + "/pregnentdb2/uploadimg.php";

//doctor
String dloginUri = "http://" + ip + "/pregnentdb2/docterlogin.php";
String dpatientlist = "http://" + ip + "/pregnentdb2/patientlist.php";
String addpatient1uri = "http://" + ip + "/pregnentdb2/addpatient1.php";
String addpatient2uri = "http://" + ip + "/pregnentdb2/addpatient2.php";
String addpatient3uri = "http://" + ip + "/pregnentdb2/addpatient3.php";
String addpatient4uri = "http://" + ip + "/pregnentdb2/addpatient4.php";
String addpatient5uri = "http://" + ip + "/pregnentdb2/addpatient5.php";
String audiouploaduri = "http://" + ip + "/pregnentdb2/audioupload.php";
String videouploaduri = "http://" + ip + "/pregnentdb2/vupload.php";
String meduploaduri = "http://" + ip + "/pregnentdb2/mupload.php";

//gaurdian
String gloginUri = "http://" + ip + "/pregnentdb2/docterlogin.php";
String gmooduri = "http://" + ip + "/pregnentdb2/gmood.php";

//admin
String aloginuri = "http://" + ip + "/pregnentdb2/adminlogin.php";
String dreguri = "http://" + ip + "/pregnentdb2/adddoctor.php";
String docdet = "http://" + ip + "/pregnentdb2/admindocdet.php";
String userid = "";

String videourl = "http://" + ip + "/pregnentdb2/";
