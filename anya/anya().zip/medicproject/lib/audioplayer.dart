import 'dart:async';
import 'package:flutter/material.dart';
import 'package:http/http.dart' as http;
import 'package:audioplayers/audioplayers.dart';
import 'package:medicproject/common.dart';
import 'package:sizer/sizer.dart';
import 'dart:convert';

class AudioPlayerPage extends StatefulWidget {
  final int audioId;

  const AudioPlayerPage({Key? key, required this.audioId}) : super(key: key);

  @override
  _AudioPlayerPageState createState() => _AudioPlayerPageState();
}

class _AudioPlayerPageState extends State<AudioPlayerPage> {
  late AudioPlayer audioPlayer;
  bool isPlaying = false;
  Duration _duration = Duration();
  Duration _position = Duration();
  double _sliderValue = 0.0;
  Timer? _timer;
  String? audioUrl;

  @override
  void initState() {
    super.initState();
    audioPlayer = AudioPlayer();
    _loadAudioUrl();

    // Listen for changes in audio duration and position
    audioPlayer.onDurationChanged.listen((Duration duration) {
      setState(() {
        _duration = duration;
      });
    });
    audioPlayer.onPositionChanged.listen((Duration position) {
      setState(() {
        _position = position;
        _sliderValue = _position.inMilliseconds.toDouble();
      });
    });
    audioPlayer.onPlayerStateChanged.listen((PlayerState state) {
      if (state == PlayerState.completed) {
        setState(() {
          isPlaying = false;
          _position = Duration.zero;
          _sliderValue = 0.0;
        });
      }
    });
  }

  Future<void> _loadAudioUrl() async {
    try {
      audioUrl = await fetchAudioUrl(widget.audioId);
      audioUrl = audioUrl?.substring(1);
    } catch (e) {
      print('Failed to fetch audio URL: $e');
    }
  }

  @override
  void dispose() {
    audioPlayer.release();
    audioPlayer.dispose();
    _timer?.cancel();
    super.dispose();
  }

  void _playPause() async {
    if (isPlaying) {
      await audioPlayer.pause();
      setState(() {
        isPlaying = false;
      });
    } else {
      if (audioUrl != null) {
        await audioPlayer.play(UrlSource(videourl + audioUrl!));
        setState(() {
          isPlaying = true;
        });
      } else {
        print('Audio URL is not available');
      }
    }
  }

  void _seekTo(double value) {
    audioPlayer.seek(Duration(milliseconds: value.toInt()));
  }

  String _formatDuration(Duration duration) {
    String twoDigits(int n) => n.toString().padLeft(2, '0');
    String twoDigitMinutes = twoDigits(duration.inMinutes.remainder(60));
    String twoDigitSeconds = twoDigits(duration.inSeconds.remainder(60));
    return "${twoDigits(duration.inHours)}:$twoDigitMinutes:$twoDigitSeconds";
  }

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      appBar: AppBar(
        title: Text('Audio Player'),
      ),
      body: Center(
        child: Container(
          width: 80.w,
          height: 60.h,
          decoration: BoxDecoration(
            borderRadius: BorderRadius.circular(10),
            color: Colors.white,
            boxShadow: [
              BoxShadow(
                color: Colors.grey.withOpacity(0.5),
                spreadRadius: 3,
                blurRadius: 7,
                offset: Offset(0, 3),
              ),
            ],
          ),
          child: Column(
            mainAxisAlignment: MainAxisAlignment.center,
            children: [
              Image.asset('assets/images/wmusic.jpeg',
                  width: 80.w, height: 40.h),
              SizedBox(height: 4.h),
              Slider(
                activeColor: Color.fromARGB(255, 248, 128, 136),
                thumbColor: Color.fromARGB(255, 248, 128, 136),
                min: 0.0,
                max: _duration.inMilliseconds.toDouble(),
                value: _sliderValue,
                onChanged: (value) {
                  setState(() {
                    _sliderValue = value;
                  });
                },
                onChangeEnd: _seekTo,
              ),
              Row(
                mainAxisAlignment: MainAxisAlignment.spaceAround,
                children: [
                  Text(_formatDuration(_position)),
                  IconButton(
                    icon: Icon(isPlaying ? Icons.pause : Icons.play_arrow),
                    onPressed: _playPause,
                  ),
                  Text(_formatDuration(_duration)),
                ],
              ),
            ],
          ),
        ),
      ),
    );
  }
}

Future<String?> fetchAudioUrl(int audioId) async {
  var url = Uri.parse(audioplayuri); // Replace with your actual URL
  var response = await http.post(url, body: {'id': audioId.toString()});

  if (response.statusCode == 200) {
    return response.body; // Adjust according to your PHP response structure
  } else {
    throw Exception('Failed to retrieve audio URL');
  }
}
